class Restaurant < ApplicationRecord
  belongs_to :user
  has_many :comments
  has_many :bookings
  has_many :users, through: :bookings

  searchable do
    text :name, :region, :location
  end
  mount_uploader :picture, PictureUploader # Tells rails to use this uploader for this model.
  validates :user_id, presence: true # Make sure the owner's name is present.
end
