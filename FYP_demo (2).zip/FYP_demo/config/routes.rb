Rails.application.routes.draw do
  resources :bookings
  resources :comments
  resources :articles
  resources :restaurants
  root to: 'visitors#index'
  devise_for :users
  resources :users
end
