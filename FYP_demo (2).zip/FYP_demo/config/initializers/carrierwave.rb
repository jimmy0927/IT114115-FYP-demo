CarrierWave.configure do |config|
  config.fog_credentials = {
      :provider               => 'AWS',                             # required
      :aws_access_key_id      => 'AKIAIXD7UTNK6XNF62LQ',            # required
      :aws_secret_access_key  => '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',     # required
      :region                 => 'ap-southeast-1'                        # optional, defaults to 'us-east-1'
  }
  config.fog_directory  = 'fyp-update-picture'               # required
# storage operations go here
end