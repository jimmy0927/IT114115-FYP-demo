FactoryGirl.define do
  factory :article do
    topic "MyString"
    article_description "MyText"
    picture "MyString"
    user_id 1
  end
end
