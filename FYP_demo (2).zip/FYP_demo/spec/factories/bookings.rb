FactoryGirl.define do
  factory :booking do
    user_id 1
    restaurant_id 1
  end
end
