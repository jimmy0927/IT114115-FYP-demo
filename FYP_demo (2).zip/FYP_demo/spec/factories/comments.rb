FactoryGirl.define do
  factory :comment do
    comment_desciption "MyText"
    user_id 1
    restaurant_id 1
  end
end
