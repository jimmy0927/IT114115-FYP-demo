FactoryGirl.define do
  factory :restaurant do
    name "MyString"
    picture "MyString"
    region "MyText"
    location "MyText"
    score 1
    score_count 1
    user_id 1
  end
end
